var searchData=
[
  ['timer_5fdelay',['TIMER_DELAY',['../hw__config_8h.html#af17622a9d50e35a2aa9925366337c722',1,'hw_config.h']]],
  ['timer_5fdelay_5fpreemption_5fpriority',['TIMER_DELAY_PREEMPTION_PRIORITY',['../main_8h.html#a063ce7881a999e0d06d7f71c54a0c415',1,'main.h']]]
];
