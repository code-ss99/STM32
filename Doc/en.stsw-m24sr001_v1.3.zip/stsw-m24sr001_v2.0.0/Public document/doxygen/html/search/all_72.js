var searchData=
[
  ['r_5fapdu',['R_APDU',['../struct_r___a_p_d_u.html',1,'']]],
  ['recordstruct',['RecordStruct',['../group__lib_n_f_c___f_o_r_u_m.html#ga0380521e581891eeea7fd8ad8562373d',1,'lib_TagType4.c']]]
];
