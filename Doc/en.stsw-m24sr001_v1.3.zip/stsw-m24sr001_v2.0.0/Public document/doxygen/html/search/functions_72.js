var searchData=
[
  ['reademail',['ReadEmail',['../group___menu___private___functions.html#ga56a5dcc8c8a8f62d466289b5ee6aef0c',1,'menu.c']]],
  ['readgeo',['ReadGeo',['../group___menu___private___functions.html#ga8ec117150aebd622172e01bf77c77da0',1,'menu.c']]],
  ['readkey',['ReadKey',['../group___menu___private___functions.html#ga7c165bf58922e98896f715219d25d5cd',1,'menu.c']]],
  ['readsms',['ReadSMS',['../group___menu___private___functions.html#gadfd005b0dbce398568de5911ec793fda',1,'menu.c']]],
  ['readuri',['ReadURI',['../group___menu___private___functions.html#ga9dae84bb95a11ea52820d9d2015d1318',1,'menu.c']]],
  ['readvcard',['ReadVcard',['../group___menu___private___functions.html#ga127d4e5686bdb0bd8366f766330463a4',1,'menu.c']]],
  ['returnfunc',['ReturnFunc',['../group___menu___private___functions.html#gad99eeb99c9b4902f08164b10d7ae4d3a',1,'menu.c']]]
];
