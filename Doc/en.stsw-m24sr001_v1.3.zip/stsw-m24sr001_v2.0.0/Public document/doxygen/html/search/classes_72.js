var searchData=
[
  ['r_5fapdu',['R_APDU',['../struct_r___a_p_d_u.html',1,'']]]
];
